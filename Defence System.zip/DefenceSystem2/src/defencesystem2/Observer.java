/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package defencesystem2;


interface Observer {
    public void setAreaClear(int areavalue);
    public void setMassage(String msg);
    public void setBtnEnable(int btnvalue);
    public void setQuickAreaClear(boolean chavalue);
    
}
